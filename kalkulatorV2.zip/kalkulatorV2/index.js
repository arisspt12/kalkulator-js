const readline = require("readline-sync");
const math = require("mathjs"); // Pastikan untuk menginstal ini jika belum: npm install mathjs

let history = [];
let previousResult = 0;

console.log("=== Selamat datang di Kalkulator ===");

function menuUtama() {
  console.log("\n=== Menu Utama ===");
  console.log("1. Kalkulasi biasa");
  console.log("2. Operasi Trigonometri (sin, cos, tan)");
  console.log("3. Akar kuadrat");
  console.log("4. Lihat Riwayat Kalkulasi");
  console.log("5. Keluar");
  return readline.question("Pilih menu (1-5): ");
}

function kalkulasiBiasa() {
  while (true) {
    const angkaPertama = previousResult || parseFloat(readline.question("Masukkan angka pertama (atau tekan Enter untuk menggunakan hasil sebelumnya): "));
    const operator = readline.question("Pilih operator (+, -, *, /, %) : ");
    const angkaKedua = parseFloat(readline.question("Masukkan angka kedua : "));

    const requiredOperator = ["+", "-", "*", "/", "%"];

    if (isNaN(angkaPertama) || isNaN(angkaKedua)) {
      console.log("Inputan tidak valid. Harap masukkan angka yang benar.\n");
      continue;
    } else if (!requiredOperator.includes(operator)) {
      console.log("Pilihan operator tidak valid. Silakan pilih dari operator yang tersedia.\n");
      continue;
    }

    let hasil;
    try {
      hasil = processHasil(angkaPertama, angkaKedua, operator);
    } catch (e) {
      console.log(`Kesalahan: ${e.message}\n`);
      continue;
    }

    console.log(`\nHasilnya adalah: ${hasil}\n`);
    history.push(`${angkaPertama} ${operator} ${angkaKedua} = ${hasil}`);
    previousResult = hasil;

    const choice = readline.question("Ingin melanjutkan perhitungan? (y/n) : ");
    if (choice.toLowerCase() !== 'y') {
      break;
    }
  }
}

function operasiTrigonometri() {
  const angka = parseFloat(readline.question("Masukkan angka (dalam derajat): "));
  const operasi = readline.question("Pilih operasi (sin, cos, tan): ");
  
  if (isNaN(angka)) {
    console.log("Inputan tidak valid. Harap masukkan angka yang benar.\n");
    return;
  }

  const radian = math.unit(angka, 'deg').toNumber('rad'); // Ubah derajat ke radian
  let hasil;
  
  switch (operasi.toLowerCase()) {
    case 'sin':
      hasil = Math.sin(radian);
      break;
    case 'cos':
      hasil = Math.cos(radian);
      break;
    case 'tan':
      hasil = Math.tan(radian);
      break;
    default:
      console.log("Operasi tidak valid. Pilih antara sin, cos, atau tan.");
      return;
  }

  console.log(`\nHasil ${operasi}(${angka}°) adalah: ${hasil}\n`);
  history.push(`${operasi}(${angka}°) = ${hasil}`);
}

function operasiAkar() {
  const angka = parseFloat(readline.question("Masukkan angka untuk menghitung akar kuadrat: "));
  
  if (isNaN(angka)) {
    console.log("Inputan tidak valid. Harap masukkan angka yang benar.\n");
    return;
  } else if (angka < 0) {
    console.log("Tidak bisa menghitung akar kuadrat dari angka negatif.\n");
    return;
  }

  const hasil = Math.sqrt(angka);
  console.log(`\nHasil akar kuadrat dari ${angka} adalah: ${hasil}\n`);
  history.push(`√${angka} = ${hasil}`);
}

function lihatRiwayat() {
  console.log("\n=== Riwayat Kalkulasi ===");
  if (history.length === 0) {
    console.log("Belum ada riwayat kalkulasi.");
  } else {
    history.forEach((item, index) => {
      console.log(`${index + 1}. ${item}`);
    });
  }
}

function processHasil(inputanPertama, inputanKedua, operator) {
  switch (operator) {
    case "+":
      return inputanPertama + inputanKedua;
    case "-":
      return inputanPertama - inputanKedua;
    case "*":
      return inputanPertama * inputanKedua;
    case "/":
      if (inputanKedua === 0) {
        throw new Error("Angka kedua tidak boleh bernilai 0.");
      }
      return inputanPertama / inputanKedua;
    case "%":
      return inputanPertama % inputanKedua;
  }
}

// Main loop
while (true) {
  const pilihan = menuUtama();

  switch (pilihan) {
    case "1":
      kalkulasiBiasa();
      break;
    case "2":
      operasiTrigonometri();
      break;
    case "3":
      operasiAkar();
      break;
    case "4":
      lihatRiwayat();
      break;
    case "5":
      console.log("Terima kasih telah menggunakan kalkulator ini.");
      process.exit(0);
    default:
      console.log("Pilihan tidak valid. Silakan pilih lagi.\n");
  }
}
